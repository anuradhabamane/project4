**Food Ordering Management System Project in PHP and MySQL Free Download** 


**Database Name: doms_db**

**Original Copy was develoed by Haxxor sid**
**Published @ codeastro.com**
**Customized and Modified Copy was made by oretnom23**
**Published @ sourcecodester.com**
**Recommended PHP Version 7.4.12 to 8**

**Admin Login Details**
Username: admin
Password: admin123

**Sample Customer Login Details**

Username: mcooper
Password: mcooper123